// lib/api.ts
import { AlertData, AlertsResponse, HeatmapPoint, StatsData  } from '@/types/detection';

  
  /**
   * API client for detection system
   */
  export class DetectionAPI {
    private baseUrl: string;
  
    /**
     * Initialize the API client
     * @param baseUrl Base URL for the API
     */
    constructor(baseUrl: string = 'http://localhost:5000/api') {
      this.baseUrl = baseUrl;
    }
  
    /**
     * Fetch alerts with optional filtering and pagination
     * @param page Page number
     * @param perPage Number of items per page
     * @param type Filter by alert type ('animal' or 'flood')
     */
    async getAlerts(
      page: number = 1, 
      perPage: number = 10, 
      type?: 'animal' | 'flood'
    ): Promise<AlertsResponse> {
      const params = new URLSearchParams({
        page: page.toString(),
        per_page: perPage.toString()
      });
  
      if (type) {
        params.append('type', type);
      }
  
      const response = await fetch(`${this.baseUrl}/alerts?${params.toString()}`);
      
      if (!response.ok) {
        throw new Error(`Failed to fetch alerts: ${response.statusText}`);
      }
  
      return await response.json() as AlertsResponse;
    }
  
    /**
     * Get a specific alert by ID
     * @param id Alert ID
     */
    async getAlert(id: number): Promise<AlertData> {
      const response = await fetch(`${this.baseUrl}/alerts/${id}`);
      
      if (!response.ok) {
        throw new Error(`Failed to fetch alert ${id}: ${response.statusText}`);
      }
  
      return await response.json() as AlertData;
    }
  
    /**
     * Get heatmap data
     * @param hours Number of hours to look back
     */
    async getHeatmapData(hours: number = 24): Promise<HeatmapPoint[]> {
      const params = new URLSearchParams({
        hours: hours.toString()
      });
  
      const response = await fetch(`${this.baseUrl}/heatmap?${params.toString()}`);
      
      if (!response.ok) {
        throw new Error(`Failed to fetch heatmap data: ${response.statusText}`);
      }
  
      const data = await response.json();
      return data.points as HeatmapPoint[];
    }
  
    /**
     * Get detection statistics
     */
    async getStats(): Promise<StatsData> {
      const response = await fetch(`${this.baseUrl}/stats`);
      
      if (!response.ok) {
        throw new Error(`Failed to fetch stats: ${response.statusText}`);
      }
  
      return await response.json() as StatsData;
    }
  
    /**
     * Helper method to format date string
     * @param date Date object or ISO string
     */
    static formatDate(date: Date | string): string {
      const d = typeof date === 'string' ? new Date(date) : date;
      return d.toLocaleString();
    }
  
    /**
     * Helper method to get alert type display name
     * @param type Alert type
     */
    static getAlertTypeDisplay(type: string): string {
      switch (type) {
        case 'animal':
          return 'Stray Animal';
        case 'flood':
          return 'Flood Risk';
        default:
          return type.charAt(0).toUpperCase() + type.slice(1);
      }
    }
  }
  
  // Default export
  export default new DetectionAPI();
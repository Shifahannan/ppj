// lib/websocket.ts
// Simplified WebSocket client with proper export

import { io, Socket } from 'socket.io-client';

/**
 * Frame update event data
 */
export interface FrameUpdate {
  image: string; // Base64 encoded image
  timestamp: string;
  camera_id: string; // Camera identifier
}

/**
 * Event handlers for WebSocket events
 */
export interface DetectionSocketEventHandlers {
  onNewAlert?: (alert: any) => void;
  onFrameUpdate?: (frame: FrameUpdate) => void;
  onConnect?: () => void;
  onDisconnect?: () => void;
  onError?: (error: Error) => void;
}

/**
 * Socket client for detection system with enhanced debugging
 */
class DetectionSocket {
  public socket: Socket | null = null;
  private eventHandlers: DetectionSocketEventHandlers = {};
  private serverUrl: string = 'http://localhost:5000';
  private debug: boolean = true;
  
  constructor() {
    // Initialize with localhost URL, will be updated when connect is called
    if (typeof window !== 'undefined') {
      // Determine server URL based on current hostname
      const hostname = window.location.hostname;
      this.serverUrl = hostname === 'localhost' 
        ? 'http://localhost:5000' 
        : `${window.location.protocol}//${hostname}:5000`;
      
      if (this.debug) console.log(`WebSocket client initialized with URL: ${this.serverUrl}`);
    }
  }
  
  connect(): void {
    if (typeof window === 'undefined') {
      console.warn('Cannot connect WebSocket in server-side environment');
      return;
    }
    
    if (this.socket && this.socket.connected) {
      if (this.debug) console.log('Socket already connected');
      return;
    }
    
    try {
      if (this.debug) console.log(`Connecting to socket server at ${this.serverUrl}`);
      
      this.socket = io(this.serverUrl, {
        transports: ['websocket', 'polling'],
        reconnection: true,
        reconnectionAttempts: 5,
        reconnectionDelay: 1000,
      });
      
      this.setupEventListeners();
    } catch (error) {
      console.error('Failed to create socket connection:', error);
    }
  }
  
  private setupEventListeners(): void {
    if (!this.socket) return;
    
    this.socket.on('connect', () => {
      if (this.debug) console.log('Connected to socket server');
      if (this.eventHandlers.onConnect) {
        this.eventHandlers.onConnect();
      }
    });
    
    this.socket.on('disconnect', () => {
      if (this.debug) console.log('Disconnected from socket server');
      if (this.eventHandlers.onDisconnect) {
        this.eventHandlers.onDisconnect();
      }
    });
    
    this.socket.on('connect_error', (error) => {
      console.error('Socket connection error:', error);
      if (this.eventHandlers.onError) {
        this.eventHandlers.onError(error instanceof Error ? error : new Error(String(error)));
      }
    });
    
    this.socket.on('new_alert', (data: any) => {
      if (this.eventHandlers.onNewAlert) {
        this.eventHandlers.onNewAlert(data);
      }
    });
    
    this.socket.on('frame_update', (data: FrameUpdate) => {
      if (this.eventHandlers.onFrameUpdate) {
        this.eventHandlers.onFrameUpdate(data);
      }
    });
  }
  
  disconnect(): void {
    if (this.socket) {
      if (this.debug) console.log('Disconnecting from socket server');
      this.socket.disconnect();
      this.socket = null;
    }
  }
  
  reconnect(): void {
    this.disconnect();
    this.connect();
  }
  
  emit(event: string, data?: any): void {
    if (this.socket && this.socket.connected) {
      if (this.debug) console.log(`Emitting socket event: ${event}`);
      this.socket.emit(event, data);
    } else {
      console.warn(`Cannot emit ${event}: Socket not connected`);
    }
  }
  
  setEventHandlers(handlers: DetectionSocketEventHandlers): void {
    this.eventHandlers = { ...this.eventHandlers, ...handlers };
  }
  
  isConnected(): boolean {
    return this.socket?.connected || false;
  }
  
  setDebug(enable: boolean): void {
    this.debug = enable;
  }
}

// Create singleton instance
const socketClient = new DetectionSocket();

// Export the instance as default
export default socketClient;
'use client';

import { divIcon } from 'leaflet';
import { AssetType } from '@/lib/constants/map-config';

// Compact icon for the small map view
export function getCompactAssetIcon(type: AssetType) {
  const iconMap = {
    vehicle: '🚗',
    drone: '🚁',
    personnel: '👤'
  };

  return divIcon({
    html: `<div class="bg-white rounded-full p-1 shadow-md text-sm">${iconMap[type]}</div>`,
    className: 'asset-icon',
    iconSize: [24, 24],
    iconAnchor: [12, 12]
  });
}

// Full-size icon for the main map view
export function getAssetIcon(type: AssetType) {
  const iconMap = {
    vehicle: '🚗',
    drone: '🚁',
    personnel: '👤'
  };

  return divIcon({
    html: `<div class="bg-white rounded-full p-2 shadow-md text-lg">${iconMap[type]}</div>`,
    className: 'asset-icon',
    iconSize: [32, 32],
    iconAnchor: [16, 16]
  });
}
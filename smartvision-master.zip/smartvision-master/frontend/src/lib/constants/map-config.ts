export const MAP_CONFIG = {
  center: [2.9264, 101.6964], // Malaysia coordinates
  zoom: 15,
  plantationBoundary: [
    [3.1390, 101.6869],
    [3.1395, 101.6880],
    [3.1385, 101.6890],
    [3.1380, 101.6879],
  ],
  assets: [
    { id: 'v1', position: [2.941127, 101.686743], type: 'vehicle', label: 'Vehicle 1' },
    { id: 'd1', position: [2.918412, 101.685418], type: 'drone', label: 'Drone 1' },
    { id: 'p1', position: [2.933763, 101.6905348], type: 'personnel', label: 'Guard 1' },
  ],
  tileLayer: {
    url: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
  }
} as const;

export type AssetType = 'vehicle' | 'drone' | 'personnel';

export interface Asset {
  id: string;
  position: [number, number];
  type: AssetType;
  label: string;
}
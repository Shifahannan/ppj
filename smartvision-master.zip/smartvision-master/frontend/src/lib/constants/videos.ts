import { Socket } from 'socket.io-client';
import { CameraConfig } from '@/types/videostream';

// Configure your cameras here
export const CAMERAS: CameraConfig[] = [
  {
    id: 'cam1',
    name: 'Main Entrance',
    url: '0', // Using default webcam (0)
    location: 'Front Gate'
  },
  // Add more cameras as needed
];

// API endpoint for your Flask backend
export const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000';

// WebSocket endpoint
export const WS_URL = process.env.NEXT_PUBLIC_WS_URL || 'http://localhost:5000';

// Utility functions for video connection
let socket: Socket | null = null;

export const getSocket = () => socket;
export const setSocket = (newSocket: Socket) => {
  socket = newSocket;
};



/* export const SAMPLE_VIDEOS = [
  '/01.mp4',
  '/02.mp4',
  // 'rtsp://username:password@camera1_ip:554/stream',
  // 'rtsp://username:password@camera2_ip:554/stream',
  // 'rtsp://username:password@camera3_ip:554/stream',
  // 'rtsp://username:password@camera4_ip:554/stream'
    
  ] as const; */
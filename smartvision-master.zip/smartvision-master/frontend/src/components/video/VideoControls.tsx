"use client";

import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Play, Pause, SkipBack, SkipForward } from "lucide-react";

interface VideoControlsProps {
  onViewChange: (view: string) => void;
  selectedView: string;
  isPlaying: boolean;
  onPlayPause: () => void;
  onSkipBack: () => void;
  onSkipForward: () => void;
}

export function VideoControls({
  onViewChange,
  selectedView,
  isPlaying,
  onPlayPause,
  onSkipBack,
  onSkipForward,
}: VideoControlsProps) {
  return (
    <div className="flex justify-between items-center mb-4">
      <Select value={selectedView} onValueChange={onViewChange}>
        <SelectTrigger className="w-[200px]">
          <SelectValue placeholder="Select View" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="all">All Cameras</SelectItem>
          <SelectItem value="entrance">Entrance Gates</SelectItem>
          <SelectItem value="perimeter">Perimeter</SelectItem>
          <SelectItem value="drones">Drone Feeds</SelectItem>
        </SelectContent>
      </Select>

      <div className="flex items-center space-x-2">
        <Button variant="outline" size="icon" onClick={onSkipBack}>
          <SkipBack className="h-4 w-4" />
        </Button>
        <Button variant="outline" size="icon" onClick={onPlayPause}>
          {isPlaying ? (
            <Pause className="h-4 w-4" />
          ) : (
            <Play className="h-4 w-4" />
          )}
        </Button>
        <Button variant="outline" size="icon" onClick={onSkipForward}>
          <SkipForward className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}

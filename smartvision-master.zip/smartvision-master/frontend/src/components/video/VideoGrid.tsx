"use client";

import { VideoPlayer } from "./VideoPlayer";

interface VideoGridProps {
  selectedView: string;
  videos: string[];
}

export function VideoGrid({ selectedView, videos }: VideoGridProps) {
  if (selectedView === "all") {
    return (
      <div className="grid grid-cols-2 md:grid-cols-2 gap-4">
        {videos.map((cameraId) => (
          <VideoPlayer key={cameraId} cameraId={cameraId} />
        ))}
      </div>
    );
  }

  // For single-camera view
  const cameraId = selectedView === "all" ? videos[0] : selectedView;
  return (
    <div className="flex justify-center">
      <VideoPlayer cameraId={cameraId} width={800} height={450} />
    </div>
  );
}

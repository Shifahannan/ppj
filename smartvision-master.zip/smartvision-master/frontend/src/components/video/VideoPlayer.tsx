// components/video/VideoPlayer.tsx

import React from "react";
import dynamic from "next/dynamic";
import { Loader2 } from "lucide-react";

// Dynamic import for VideoStream to prevent SSR issues
const VideoStream = dynamic(() => import("./VideoStream"), {
  ssr: false,
  loading: () => (
    <div
      className="flex items-center justify-center bg-muted"
      style={{ height: 180, width: 320 }}
    >
      <Loader2 className="h-6 w-6 animate-spin text-primary" />
    </div>
  ),
});

interface VideoPlayerProps {
  src?: string; // Keep for backward compatibility
  cameraId: number | string;
  width?: number;
  height?: number;
}

export function VideoPlayer({
  cameraId,
  width = 320,
  height = 180,
}: VideoPlayerProps) {
  // Convert number cameraId to string format if needed
  const formattedCameraId =
    typeof cameraId === "number" ? `cam${cameraId}` : cameraId;

  return (
    <div className="video-player rounded-md overflow-hidden relative">
      <VideoStream cameraId={formattedCameraId} width={width} height={height} />
      <div className="absolute bottom-0 right-0 bg-black bg-opacity-60 text-white text-xs p-1 rounded-tl-md">
        Camera {cameraId}
      </div>
    </div>
  );
}

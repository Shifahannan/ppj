// components/video/VideoStream.tsx

import React, { useEffect, useState, useRef } from "react";
import socketClient, { FrameUpdate } from "@/lib/websocket";

interface VideoStreamProps {
  cameraId?: string;
  width?: number;
  height?: number;
}

const VideoStream: React.FC<VideoStreamProps> = ({
  cameraId = "cam1",
  width = 640,
  height = 480,
}) => {
  const [isConnected, setIsConnected] = useState(false);
  const [error, setError] = useState<Error | null>(null);
  const [frame, setFrame] = useState<FrameUpdate | null>(null);
  const [frameCount, setFrameCount] = useState(0);
  const lastFrameTimeRef = useRef<Date | null>(null);
  const [isSubscribed, setIsSubscribed] = useState(false);

  // Handle frame updates
  const handleFrameUpdate = (frameData: FrameUpdate) => {
    // Only process frames for our camera
    if (frameData.camera_id === cameraId) {
      setFrameCount((prev) => prev + 1);
      setFrame(frameData);
      lastFrameTimeRef.current = new Date();
    }
  };

  // Function to subscribe to video feed
  const subscribeToVideo = () => {
    if (!socketClient.isConnected()) {
      console.log("Cannot subscribe: Socket not connected");
      return;
    }

    console.log(`Subscribing to video feed for camera ${cameraId}`);
    socketClient.emit("subscribe_video", { camera_id: cameraId });
  };

  // Set up websocket connection and event handlers
  useEffect(() => {
    console.log(`VideoStream component mounted for camera ${cameraId}`);

    // Set event handlers
    const handleConnect = () => {
      console.log("Socket connected in VideoStream component");
      setIsConnected(true);
      setError(null);

      // Subscribe to video feed after connection
      setTimeout(subscribeToVideo, 500);
    };

    const handleDisconnect = () => {
      console.log("Socket disconnected in VideoStream component");
      setIsConnected(false);
      setIsSubscribed(false);
    };

    const handleError = (err: Error) => {
      console.error("Socket error in VideoStream component:", err);
      setError(err);
    };

    // Set up handler for subscription acknowledgment
    const handleSubscriptionAck = (data: any) => {
      console.log("Video subscription acknowledged:", data);
      setIsSubscribed(true);
    };

    // Set the event handlers for the socket
    socketClient.setEventHandlers({
      onConnect: handleConnect,
      onDisconnect: handleDisconnect,
      onError: handleError,
      onFrameUpdate: handleFrameUpdate,
    });

    // Check if socket is already connected
    if (socketClient.isConnected()) {
      console.log("Socket already connected, subscribing to video feed");
      setIsConnected(true);
      subscribeToVideo();
    } else {
      console.log("Socket not connected, connecting...");
      socketClient.connect();
    }

    // Add subscription ack listener if socket exists
    if (socketClient.socket) {
      socketClient.socket.on("video_subscription_ack", handleSubscriptionAck);
    }

    // Cleanup function
    return () => {
      console.log(`VideoStream component unmounting for camera ${cameraId}`);

      // Unsubscribe from video feed if connected and subscribed
      if (socketClient.isConnected() && isSubscribed) {
        console.log("Unsubscribing from video feed");
        socketClient.emit("unsubscribe_video");
      }

      // Remove subscription ack listener if socket exists
      if (socketClient.socket) {
        socketClient.socket.off(
          "video_subscription_ack",
          handleSubscriptionAck
        );
      }
    };
  }, [cameraId]);

  // Handle reconnect button click
  const handleReconnect = () => {
    console.log("Reconnecting socket");
    socketClient.reconnect();
  };

  // If we're server-side rendering, return a placeholder
  if (typeof window === "undefined") {
    return (
      <div
        className="flex items-center justify-center bg-muted"
        style={{ width, height }}
      >
        <div>Loading...</div>
      </div>
    );
  }

  return (
    <div className="video-stream">
      <div
        className="video-container"
        style={{ width, height, position: "relative" }}
      >
        {isConnected ? (
          frame ? (
            <>
              <img
                src={`data:image/jpeg;base64,${frame.image}`}
                alt="Video Stream"
                width={width}
                height={height}
                style={{ objectFit: "cover" }}
              />
              <div
                className="timestamp"
                style={{
                  position: "absolute",
                  bottom: "10px",
                  left: "10px",
                  backgroundColor: "rgba(0,0,0,0.5)",
                  color: "white",
                  padding: "5px",
                  borderRadius: "3px",
                  fontSize: "12px",
                }}
              >
                {frame.timestamp} - {frame.camera_id} - Frames: {frameCount}
              </div>
            </>
          ) : (
            <div
              className="loading"
              style={{
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                justifyContent: "center",
                width: "100%",
                height: "100%",
                backgroundColor: "#f0f0f0",
              }}
            >
              <p>Waiting for video stream...</p>
              <p style={{ fontSize: "12px", marginTop: "10px" }}>
                {isSubscribed
                  ? "Subscribed, waiting for frames..."
                  : "Connected to server, subscribing to video feed..."}
              </p>
              <div style={{ marginTop: "15px", display: "flex", gap: "10px" }}>
                <button
                  onClick={subscribeToVideo}
                  style={{
                    padding: "5px 10px",
                    backgroundColor: "#2196f3",
                    color: "white",
                    border: "none",
                    borderRadius: "4px",
                    cursor: "pointer",
                    fontSize: "12px",
                  }}
                >
                  Subscribe
                </button>
              </div>
            </div>
          )
        ) : (
          <div
            className="disconnected"
            style={{
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              width: "100%",
              height: "100%",
              backgroundColor: "#ff000020",
              color: "#d32f2f",
              gap: "10px",
            }}
          >
            <div>
              {error
                ? `Connection error: ${error.message}`
                : "Connection lost. Attempting to reconnect..."}
            </div>
            <button
              onClick={handleReconnect}
              style={{
                padding: "8px 16px",
                backgroundColor: "#2196f3",
                color: "white",
                border: "none",
                borderRadius: "4px",
                cursor: "pointer",
              }}
            >
              Reconnect
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default VideoStream;

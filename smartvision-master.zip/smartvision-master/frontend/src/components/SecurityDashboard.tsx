"use client";

import { useState, useEffect } from "react";
import { Header } from "@/components/dashboard/Header";
import { Sidebar } from "@/components/dashboard/Sidebar";
import { MainDashboard } from "@/components/dashboard/MainDashboard";
import { MapViewPage } from "@/components/dashboard/pages/MapViewPage";
import { VideoFeedsPage } from "@/components/dashboard/pages/VideoFeedsPage";
import { AnalyticsPage } from "@/components/dashboard/pages/AnalyticsPage";
import { SettingsPage } from "@/components/dashboard/pages/SettingsPage";

export type Page = "dashboard" | "map" | "video" | "analytics" | "settings";

export default function SecurityDashboard() {
  const [currentPage, setCurrentPage] = useState<Page>("dashboard");
  const [isMounted, setIsMounted] = useState(false);

  useEffect(() => {
    setIsMounted(true);
  }, []);

  const renderPage = () => {
    if (!isMounted) return null;

    switch (currentPage) {
      case "dashboard":
        return <MainDashboard />;
      case "map":
        return <MapViewPage />;
      case "video":
        return <VideoFeedsPage />;
      case "analytics":
        return <AnalyticsPage />;
      case "settings":
        return <SettingsPage />;
      default:
        return <MainDashboard />;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <div className="flex h-[calc(100vh-4rem)]">
        <Sidebar currentPage={currentPage} setCurrentPage={setCurrentPage} />
        <main className="flex-1 overflow-auto p-4">{renderPage()}</main>
      </div>
    </div>
  );
}

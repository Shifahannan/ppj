// components/debug/SocketDebug.tsx
"use client";

import { useState, useEffect } from "react";
import socketClient from "@/lib/websocket";

export default function SocketDebug() {
  const [isVisible, setIsVisible] = useState(false);
  const [isConnected, setIsConnected] = useState(false);
  const [frameCount, setFrameCount] = useState(0);
  const [messages, setMessages] = useState<string[]>([]);
  const [selectedCamera, setSelectedCamera] = useState("cam1");

  useEffect(() => {
    // Set up event handlers
    const handleConnect = () => {
      setIsConnected(true);
      addMessage("Connected to socket server");
    };

    const handleDisconnect = () => {
      setIsConnected(false);
      addMessage("Disconnected from socket server");
    };

    const handleError = (err: Error) => {
      addMessage(`Error: ${err.message}`);
    };

    const handleFrameUpdate = (data: any) => {
      setFrameCount((prev) => prev + 1);
      if (frameCount % 10 === 0) {
        addMessage(
          `Received frame ${frameCount} from camera ${data.camera_id}`
        );
      }
    };

    socketClient.setEventHandlers({
      onConnect: handleConnect,
      onDisconnect: handleDisconnect,
      onError: handleError,
      onFrameUpdate: handleFrameUpdate,
    });

    // Check initial connection state
    setIsConnected(socketClient.isConnected());

    // Add subscription acknowledgment listener
    if (socketClient.socket) {
      socketClient.socket.on("video_subscription_ack", (data) => {
        addMessage(`Video subscription acknowledged: ${JSON.stringify(data)}`);
      });

      socketClient.socket.on("pong", (data) => {
        addMessage(`Pong received: ${JSON.stringify(data)}`);
      });
    }

    // Cleanup
    return () => {
      if (socketClient.socket) {
        socketClient.socket.off("video_subscription_ack");
        socketClient.socket.off("pong");
      }
    };
  }, [frameCount]);

  // Add message to the log
  const addMessage = (msg: string) => {
    setMessages((prev) => {
      const now = new Date();
      const timestamp = now.toLocaleTimeString();
      const newMessages = [...prev, `[${timestamp}] ${msg}`];

      // Keep only the last 50 messages
      if (newMessages.length > 50) {
        return newMessages.slice(-50);
      }
      return newMessages;
    });
  };

  // Connect to socket
  const handleConnect = () => {
    addMessage("Connecting to socket server...");
    socketClient.connect();
  };

  // Disconnect from socket
  const handleDisconnect = () => {
    addMessage("Disconnecting from socket server...");
    socketClient.disconnect();
  };

  // Subscribe to video feed
  const handleSubscribe = () => {
    addMessage(`Subscribing to camera ${selectedCamera}...`);
    socketClient.emit("subscribe_video", { camera_id: selectedCamera });
  };

  // Unsubscribe from video feed
  const handleUnsubscribe = () => {
    addMessage("Unsubscribing from video feed...");
    socketClient.emit("unsubscribe_video");
  };

  // Ping server
  const handlePing = () => {
    addMessage("Pinging server...");
    socketClient.emit("ping_server", {
      client: "debug-component",
      time: new Date().toISOString(),
    });
  };

  // Toggle visibility
  const toggleVisibility = () => {
    setIsVisible(!isVisible);
  };

  return (
    <div className="relative">
      {/* Toggle button - always visible */}
      <button
        onClick={toggleVisibility}
        className="fixed bottom-4 right-4 z-50 bg-blue-500 text-white px-3 py-1 rounded shadow-lg text-sm"
      >
        {isVisible ? "Hide Debug" : "Socket Debug"}
      </button>

      {/* Debug panel */}
      {isVisible && (
        <div className="fixed bottom-16 right-4 z-50 bg-gray-900 text-white p-4 rounded-md shadow-lg w-80 max-h-[80vh] flex flex-col">
          <div className="flex justify-between items-center mb-2">
            <h3 className="font-bold">Socket Debugger</h3>
            <div className="flex items-center">
              <div
                className={`w-3 h-3 rounded-full mr-2 ${
                  isConnected ? "bg-green-500" : "bg-red-500"
                }`}
              ></div>
              <span>{isConnected ? "Connected" : "Disconnected"}</span>
            </div>
          </div>

          <div className="flex gap-2 mb-2">
            <button
              onClick={handleConnect}
              disabled={isConnected}
              className={`px-2 py-1 text-xs rounded ${
                isConnected ? "bg-gray-700" : "bg-blue-600 hover:bg-blue-700"
              }`}
            >
              Connect
            </button>
            <button
              onClick={handleDisconnect}
              disabled={!isConnected}
              className={`px-2 py-1 text-xs rounded ${
                !isConnected ? "bg-gray-700" : "bg-red-600 hover:bg-red-700"
              }`}
            >
              Disconnect
            </button>
            <button
              onClick={handlePing}
              disabled={!isConnected}
              className={`px-2 py-1 text-xs rounded ${
                !isConnected
                  ? "bg-gray-700"
                  : "bg-purple-600 hover:bg-purple-700"
              }`}
            >
              Ping
            </button>
          </div>

          <div className="flex gap-2 mb-2 items-center">
            <select
              value={selectedCamera}
              onChange={(e) => setSelectedCamera(e.target.value)}
              className="bg-gray-800 text-white text-xs px-2 py-1 rounded flex-1"
            >
              <option value="cam1">Camera 1</option>
              <option value="cam2">Camera 2</option>
              <option value="cam3">Camera 3</option>
              <option value="cam4">Camera 4</option>
            </select>
            <button
              onClick={handleSubscribe}
              disabled={!isConnected}
              className={`px-2 py-1 text-xs rounded ${
                !isConnected ? "bg-gray-700" : "bg-green-600 hover:bg-green-700"
              }`}
            >
              Subscribe
            </button>
            <button
              onClick={handleUnsubscribe}
              disabled={!isConnected}
              className={`px-2 py-1 text-xs rounded ${
                !isConnected
                  ? "bg-gray-700"
                  : "bg-yellow-600 hover:bg-yellow-700"
              }`}
            >
              Unsub
            </button>
          </div>

          <div className="text-xs mb-2">Frames received: {frameCount}</div>

          <div className="overflow-y-auto flex-1 bg-gray-800 p-2 rounded text-xs font-mono">
            {messages.length > 0 ? (
              messages.map((msg, index) => (
                <div key={index} className="mb-1 whitespace-normal break-words">
                  {msg}
                </div>
              ))
            ) : (
              <div className="text-gray-500 italic">No messages yet</div>
            )}
          </div>

          <div className="mt-2 text-center">
            <button
              onClick={() => setMessages([])}
              className="px-2 py-1 text-xs bg-gray-700 hover:bg-gray-600 rounded"
            >
              Clear Log
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

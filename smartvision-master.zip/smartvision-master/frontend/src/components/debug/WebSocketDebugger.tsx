// components/debug/WebSocketDebugger.tsx

import React, { useState, useEffect, useRef } from "react";
import socketClient from "@/lib/websocket";

interface LogEntry {
  timestamp: string;
  message: string;
  type: "info" | "error" | "warn" | "success";
}

export const WebSocketDebugger: React.FC = () => {
  const [isConnected, setIsConnected] = useState(false);
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [showDebugger, setShowDebugger] = useState(false);
  const [subscribed, setSubscribed] = useState(false);
  const [frameCount, setFrameCount] = useState(0);
  const logContainerRef = useRef<HTMLDivElement>(null);
  const cameraIdRef = useRef<HTMLInputElement>(null);

  // Add a log entry
  const addLog = (
    message: string,
    type: "info" | "error" | "warn" | "success" = "info"
  ) => {
    const now = new Date();
    const timestamp = now.toISOString().split("T")[1].substring(0, 8);

    setLogs((prevLogs) => {
      const newLogs = [
        ...prevLogs,
        {
          timestamp,
          message,
          type,
        },
      ];

      // Keep only the last 100 logs
      if (newLogs.length > 100) {
        return newLogs.slice(-100);
      }
      return newLogs;
    });
  };

  // Setup socket event handlers
  useEffect(() => {
    const handleConnect = () => {
      setIsConnected(true);
      addLog("Socket connected", "success");
    };

    const handleDisconnect = () => {
      setIsConnected(false);
      addLog("Socket disconnected", "error");
      setSubscribed(false);
    };

    const handleError = (error: Error) => {
      addLog(`Socket error: ${error.message}`, "error");
    };

    const handleFrame = () => {
      setFrameCount((prev) => prev + 1);
      // Only log every 30 frames to avoid spam
      if (frameCount % 30 === 0) {
        addLog(`Received frame #${frameCount}`, "info");
      }
    };

    // Setup event handlers
    socketClient.setEventHandlers({
      onConnect: handleConnect,
      onDisconnect: handleDisconnect,
      onError: handleError,
      onFrameUpdate: handleFrame,
    });

    // Check initial connection state
    setIsConnected(socketClient.isConnected());
    if (socketClient.isConnected()) {
      addLog("Socket already connected", "success");
    }

    // Listen for subscription acknowledgment
    socketClient.socket?.on("video_subscription_ack", (data) => {
      addLog(
        `Video subscription acknowledged: ${JSON.stringify(data)}`,
        "success"
      );
      setSubscribed(true);
    });

    return () => {
      // Remove subscription ack listener
      socketClient.socket?.off("video_subscription_ack");
    };
  }, [frameCount]);

  // Auto-scroll logs to bottom
  useEffect(() => {
    if (logContainerRef.current) {
      logContainerRef.current.scrollTop = logContainerRef.current.scrollHeight;
    }
  }, [logs]);

  // Connect to socket
  const handleConnect = () => {
    addLog("Connecting to socket...", "info");
    socketClient.connect();
  };

  // Disconnect from socket
  const handleDisconnect = () => {
    addLog("Disconnecting from socket...", "info");
    socketClient.disconnect();
  };

  // Subscribe to video feed
  const handleSubscribe = () => {
    const cameraId = cameraIdRef.current?.value || "cam1";
    addLog(`Subscribing to video feed for camera ${cameraId}...`, "info");
    socketClient.emit("subscribe_video", { camera_id: cameraId });
  };

  // Unsubscribe from video feed
  const handleUnsubscribe = () => {
    addLog("Unsubscribing from video feed...", "info");
    socketClient.emit("unsubscribe_video");
    setSubscribed(false);
  };

  // Ping server
  const handlePing = () => {
    addLog("Pinging server...", "info");
    socketClient.emit("ping_server", { time: new Date().toISOString() });
  };

  // Clear logs
  const handleClearLogs = () => {
    setLogs([]);
    setFrameCount(0);
  };

  // Toggle debugger visibility
  const toggleDebugger = () => {
    setShowDebugger(!showDebugger);
  };

  // Render the debugger
  return (
    <div className="relative">
      {/* Floating toggle button */}
      <button
        onClick={toggleDebugger}
        className="fixed bottom-4 right-4 z-50 bg-blue-500 hover:bg-blue-600 text-white px-3 py-1 rounded-md shadow-lg text-sm"
      >
        {showDebugger ? "Hide Debugger" : "Show WebSocket Debugger"}
      </button>

      {/* Debugger panel */}
      {showDebugger && (
        <div className="fixed bottom-16 right-4 z-50 bg-gray-800 text-white rounded-lg shadow-xl p-4 w-96 max-h-[80vh] flex flex-col">
          <h3 className="text-lg font-semibold mb-2 flex justify-between">
            <span>WebSocket Debugger</span>
            <button
              onClick={toggleDebugger}
              className="text-gray-400 hover:text-white"
            >
              &times;
            </button>
          </h3>

          <div className="mb-2 flex items-center gap-2">
            <span
              className={`w-3 h-3 rounded-full ${
                isConnected ? "bg-green-500" : "bg-red-500"
              }`}
            ></span>
            <span>{isConnected ? "Connected" : "Disconnected"}</span>
            <span className="ml-auto text-xs">
              {frameCount > 0 && `${frameCount} frames`}
            </span>
          </div>

          <div className="grid grid-cols-2 gap-2 mb-2">
            <button
              onClick={handleConnect}
              disabled={isConnected}
              className={`px-2 py-1 rounded text-sm ${
                isConnected
                  ? "bg-gray-600 text-gray-400"
                  : "bg-blue-600 hover:bg-blue-700"
              }`}
            >
              Connect
            </button>
            <button
              onClick={handleDisconnect}
              disabled={!isConnected}
              className={`px-2 py-1 rounded text-sm ${
                !isConnected
                  ? "bg-gray-600 text-gray-400"
                  : "bg-red-600 hover:bg-red-700"
              }`}
            >
              Disconnect
            </button>
          </div>

          <div className="mb-2 flex gap-2">
            <input
              ref={cameraIdRef}
              type="text"
              defaultValue="cam1"
              placeholder="Camera ID"
              className="bg-gray-700 px-2 py-1 rounded text-sm flex-1 border border-gray-600"
            />
            <button
              onClick={handleSubscribe}
              disabled={!isConnected || subscribed}
              className={`px-2 py-1 rounded text-sm ${
                !isConnected || subscribed
                  ? "bg-gray-600 text-gray-400"
                  : "bg-green-600 hover:bg-green-700"
              }`}
            >
              Subscribe
            </button>
            <button
              onClick={handleUnsubscribe}
              disabled={!isConnected || !subscribed}
              className={`px-2 py-1 rounded text-sm ${
                !isConnected || !subscribed
                  ? "bg-gray-600 text-gray-400"
                  : "bg-yellow-600 hover:bg-yellow-700"
              }`}
            >
              Unsubscribe
            </button>
          </div>

          <div className="mb-2 grid grid-cols-2 gap-2">
            <button
              onClick={handlePing}
              disabled={!isConnected}
              className={`px-2 py-1 rounded text-sm ${
                !isConnected
                  ? "bg-gray-600 text-gray-400"
                  : "bg-purple-600 hover:bg-purple-700"
              }`}
            >
              Ping Server
            </button>
            <button
              onClick={handleClearLogs}
              className="px-2 py-1 rounded text-sm bg-gray-600 hover:bg-gray-700"
            >
              Clear Logs
            </button>
          </div>

          <div
            ref={logContainerRef}
            className="bg-gray-900 p-2 rounded flex-1 overflow-y-auto text-xs font-mono"
          >
            {logs.map((log, index) => (
              <div
                key={index}
                className={`mb-1 ${
                  log.type === "error"
                    ? "text-red-400"
                    : log.type === "warn"
                    ? "text-yellow-400"
                    : log.type === "success"
                    ? "text-green-400"
                    : "text-gray-300"
                }`}
              >
                [{log.timestamp}] {log.message}
              </div>
            ))}
            {logs.length === 0 && (
              <div className="text-gray-500 italic">No logs yet</div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default WebSocketDebugger;

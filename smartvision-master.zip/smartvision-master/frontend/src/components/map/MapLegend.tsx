"use client";

import { Badge } from "@/components/ui/badge";
import { MapPin, Truck, User, Move } from "lucide-react";
import { MAP_CONFIG } from "@/lib/constants/map-config";

const LEGEND_ITEMS = [
  { icon: MapPin, label: "Plantation Zones", count: null },
  {
    icon: Truck,
    label: "Vehicles",
    count: MAP_CONFIG.assets.filter((a) => a.type === "vehicle").length,
  },
  {
    icon: User,
    label: "Personnel",
    count: MAP_CONFIG.assets.filter((a) => a.type === "personnel").length,
  },
  {
    icon: Move,
    label: "Drones",
    count: MAP_CONFIG.assets.filter((a) => a.type === "drone").length,
  },
] as const;

export function MapLegend() {
  return (
    <div className="absolute top-4 left-4 z-10 space-y-2">
      {LEGEND_ITEMS.map((item, index) => (
        <Badge
          key={index}
          variant="secondary"
          className="flex items-center gap-1"
        >
          <item.icon className="h-4 w-4" />
          {item.label}
          {item.count !== null && ` (${item.count})`}
        </Badge>
      ))}
    </div>
  );
}

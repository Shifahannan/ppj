"use client";

import { useMap } from "react-leaflet";
import { Button } from "@/components/ui/button";
import { ZoomIn, ZoomOut, Crosshair } from "lucide-react";
import { MAP_CONFIG } from "@/lib/constants/map-config";

export function MapControls() {
  const map = useMap();

  return (
    <div className="absolute top-4 right-4 z-[1000] bg-background/90 backdrop-blur-sm rounded-lg shadow-lg p-2 space-y-2">
      <Button
        variant="ghost"
        size="icon"
        onClick={() => map.zoomIn()}
        title="Zoom In"
      >
        <ZoomIn className="h-4 w-4" />
      </Button>
      <Button
        variant="ghost"
        size="icon"
        onClick={() => map.zoomOut()}
        title="Zoom Out"
      >
        <ZoomOut className="h-4 w-4" />
      </Button>
      <Button
        variant="ghost"
        size="icon"
        onClick={() =>
          map.setView(MAP_CONFIG.center as [number, number], MAP_CONFIG.zoom)
        }
        title="Center Map"
      >
        <Crosshair className="h-4 w-4" />
      </Button>
    </div>
  );
}

/* eslint-disable @typescript-eslint/no-explicit-any */
"use client";

import { useState, useEffect, useMemo } from "react";
import { MapContainer, TileLayer } from "react-leaflet";
import { Card } from "@/components/ui/card";
import { MAP_CONFIG } from "@/lib/constants/map-config";
import { MapControls } from "./MapControls";
import { MapLegend } from "./MapLegend";
import { PlantationBoundary } from "./layers/PlantationBoundary";
import { AssetMarkers } from "./layers/AssetMarkers";
import "leaflet/dist/leaflet.css";
import L from "leaflet";

// Prevent multiple icon initializations
const initializeLeafletIcons = () => {
  if (
    typeof window !== "undefined" &&
    !(window as any).leafletIconsInitialized
  ) {
    delete (L.Icon.Default.prototype as any)._getIconUrl;
    L.Icon.Default.mergeOptions({
      iconRetinaUrl: "/leaflet/marker-icon-2x.png",
      iconUrl: "/leaflet/marker-icon.png",
      shadowUrl: "/leaflet/marker-shadow.png",
    });
    (window as any).leafletIconsInitialized = true;
  }
};

export function Map() {
  const [key] = useState(0);

  useEffect(() => {
    initializeLeafletIcons();
  }, []);

  // Unique key to force re-render
  const mapKey = useMemo(() => `map-${key}`, [key]);

  return (
    <Card className="md:col-span-3 relative h-[600px]">
      <MapLegend />
      <MapContainer
        key={mapKey}
        center={MAP_CONFIG.center as [number, number]}
        zoom={MAP_CONFIG.zoom}
        className="h-full w-full rounded-lg z-0"
        // Prevent scrolling and dragging to reduce initialization issues
        scrollWheelZoom={false}
        dragging={false}
        zoomControl={false}
      >
        <TileLayer
          url={MAP_CONFIG.tileLayer.url}
          attribution={MAP_CONFIG.tileLayer.attribution}
        />
        <PlantationBoundary />
        <AssetMarkers />
        <MapControls />
      </MapContainer>
    </Card>
  );
}

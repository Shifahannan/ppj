"use client";

import { RefObject } from "react";
import { LoadingSpinner } from "@/components/ui/loading-spinner";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertTriangle } from "lucide-react";

interface MapContainerProps {
  mapRef: RefObject<HTMLDivElement>;
  error: Error | null;
  isLoading: boolean;
  controls: React.ReactNode;
  legend: React.ReactNode;
}

export function MapContainer({
  mapRef,
  error,
  isLoading,
  controls,
  legend,
}: MapContainerProps) {
  if (isLoading) {
    return (
      <div className="md:col-span-3 h-[600px] flex items-center justify-center">
        <LoadingSpinner />
      </div>
    );
  }

  if (error) {
    return (
      <div className="md:col-span-3">
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            Failed to load map: {error.message}
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  return (
    <div className="md:col-span-3 relative">
      {controls}
      {legend}
      <div
        ref={mapRef}
        className="h-[600px] w-full rounded-lg overflow-hidden"
        suppressHydrationWarning // Add this to prevent hydration warning
      />
    </div>
  );
}

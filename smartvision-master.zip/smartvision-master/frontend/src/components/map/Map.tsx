/* eslint-disable @typescript-eslint/no-explicit-any */
"use client";

import { useEffect } from "react";
import { MapContainer, TileLayer } from "react-leaflet";
import { Card } from "@/components/ui/card";
import { MAP_CONFIG } from "@/lib/constants/map-config";
import { MapControls } from "./MapControls";
import { MapLegend } from "./MapLegend";
import { PlantationBoundary } from "./layers/PlantationBoundary";
import { AssetMarkers } from "./layers/AssetMarkers";
import "leaflet/dist/leaflet.css";
import L from "leaflet";

export function Map() {
  // Fix for Leaflet icons in Next.js
  useEffect(() => {
    (async function init() {
      delete (L.Icon.Default.prototype as any)._getIconUrl;
      L.Icon.Default.mergeOptions({
        iconRetinaUrl: "/leaflet/marker-icon-2x.png",
        iconUrl: "/leaflet/marker-icon.png",
        shadowUrl: "/leaflet/marker-shadow.png",
      });
    })();
  }, []);

  return (
    <Card className="md:col-span-3 relative h-[600px]">
      <MapLegend />
      <MapContainer
        center={MAP_CONFIG.center as [number, number]}
        zoom={MAP_CONFIG.zoom}
        className="h-full w-full rounded-lg z-0"
      >
        <TileLayer
          url={MAP_CONFIG.tileLayer.url}
          attribution={MAP_CONFIG.tileLayer.attribution}
        />
        <PlantationBoundary />
        <AssetMarkers />
        <MapControls />
      </MapContainer>
    </Card>
  );
}

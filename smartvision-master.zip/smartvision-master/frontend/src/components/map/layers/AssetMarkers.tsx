"use client";

import { Marker, Popup } from "react-leaflet";
import { MAP_CONFIG, Asset } from "@/lib/constants/map-config";
import { getAssetIcon } from "@/lib/utils/map-utils";

export function AssetMarkers() {
  return (
    <>
      {MAP_CONFIG.assets.map((asset: Asset) => (
        <Marker
          key={asset.id}
          position={asset.position as [number, number]}
          icon={getAssetIcon(asset.type)}
        >
          <Popup>
            <div className="p-2">
              <h3 className="font-semibold">{asset.label}</h3>
              <p className="text-sm text-muted-foreground">
                {asset.type.charAt(0).toUpperCase() + asset.type.slice(1)}
              </p>
            </div>
          </Popup>
        </Marker>
      ))}
    </>
  );
}

"use client";

import { Polygon } from "react-leaflet";
import { MAP_CONFIG } from "@/lib/constants/map-config";

export function PlantationBoundary() {
  return (
    <Polygon
      positions={MAP_CONFIG.plantationBoundary as unknown as [number, number][]}
      pathOptions={{
        color: "red",
        weight: 2,
        fillColor: "red",
        fillOpacity: 0.15,
      }}
    />
  );
}

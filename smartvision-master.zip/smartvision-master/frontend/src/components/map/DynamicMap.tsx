"use client";

import dynamic from "next/dynamic";
import { Card } from "@/components/ui/card";
//import { Skeleton } from "@/components/ui/skeleton";
import { LoadingSpinner } from "@/components/ui/loading-spinner";

// Dynamically import the map component with no SSR
const Map = dynamic(() => import("./Map").then((mod) => mod.Map), {
  ssr: false,
  loading: () => (
    <Card className="md:col-span-3 h-[600px] flex items-center justify-center">
      <LoadingSpinner />
    </Card>
  ),
});

export function DynamicMap() {
  return <Map />;
}

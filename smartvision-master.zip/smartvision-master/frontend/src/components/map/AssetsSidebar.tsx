"use client";

import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { MAP_CONFIG } from "@/lib/constants/map-config";

const ASSET_COUNTS = {
  vehicles: {
    current: MAP_CONFIG.assets.filter((a) => a.type === "vehicle").length,
    total: 15,
  },
  personnel: {
    current: MAP_CONFIG.assets.filter((a) => a.type === "personnel").length,
    total: 50,
  },
  drones: {
    current: MAP_CONFIG.assets.filter((a) => a.type === "drone").length,
    total: 4,
  },
} as const;

export function AssetsSidebar() {
  return (
    <div className="space-y-4">
      <Card className="p-4">
        <h3 className="font-semibold mb-2">Active Assets</h3>
        <div className="space-y-2">
          {Object.entries(ASSET_COUNTS).map(([key, value]) => (
            <div key={key} className="flex justify-between items-center">
              <span>{key.charAt(0).toUpperCase() + key.slice(1)}</span>
              <Badge>
                {value.current}/{value.total}
              </Badge>
            </div>
          ))}
        </div>
      </Card>

      <Card className="p-4">
        <h3 className="font-semibold mb-2">Recent Activity</h3>
        <div className="space-y-2 text-sm">
          <p>Vehicle #23 entered Zone A</p>
          <p>Drone #2 completed patrol</p>
          <p>New personnel badge scan</p>
        </div>
      </Card>
    </div>
  );
}

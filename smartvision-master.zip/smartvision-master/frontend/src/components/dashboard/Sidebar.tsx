"use client";

import { Map, Video, BarChart2, Settings, LayoutDashboard } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import type { Page } from "@/components/SecurityDashboard";

interface SidebarProps {
  currentPage: Page;
  setCurrentPage: (page: Page) => void;
}

const navItems = [
  { icon: LayoutDashboard, label: "Dashboard", value: "dashboard" },
  { icon: Map, label: "Map View", value: "map" },
  { icon: Video, label: "Video Feeds", value: "video" },
  { icon: BarChart2, label: "Analytics", value: "analytics" },
  { icon: Settings, label: "Settings", value: "settings" },
] as const;

export function Sidebar({ currentPage, setCurrentPage }: SidebarProps) {
  return (
    <div className="w-64 border-r bg-card p-4">
      <nav className="space-y-2">
        {navItems.map((item) => (
          <Button
            key={item.value}
            variant={currentPage === item.value ? "secondary" : "ghost"}
            className={cn(
              "w-full justify-start gap-2",
              currentPage === item.value && "bg-secondary"
            )}
            onClick={() => setCurrentPage(item.value as Page)}
          >
            <item.icon className="h-5 w-5" />
            {item.label}
          </Button>
        ))}
      </nav>
    </div>
  );
}

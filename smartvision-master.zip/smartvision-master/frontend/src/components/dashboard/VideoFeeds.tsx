"use client";

import { useState, useEffect } from "react";
import { VideoControls } from "@/components/video/VideoControls";
import { VideoGrid } from "@/components/video/VideoGrid";
import socketClient from "@/lib/websocket";

// Define camera IDs - these should match what your backend sends
const CAMERA_IDS = ["cam1", "cam2", "cam3", "cam4"];

export function VideoFeeds() {
  const [selectedView, setSelectedView] = useState("all");
  const [isPlaying, setIsPlaying] = useState(true);
  const [isConnected, setIsConnected] = useState(false);

  useEffect(() => {
    // Set up connection status monitoring
    socketClient.setEventHandlers({
      onConnect: () => setIsConnected(true),
      onDisconnect: () => setIsConnected(false),
    });

    // Connect to WebSocket server
    socketClient.connect();

    return () => {
      // Just remove our handlers, don't disconnect as other components may use it
      socketClient.setEventHandlers({});
    };
  }, []);

  const handlePlayPause = () => {
    setIsPlaying(!isPlaying);
    // The actual pause functionality would need to be implemented on your backend
    // You could send a message to pause/resume camera streams
  };

  const handleSkipBack = () => {
    // Implementation for skipping back would require backend support
    console.log("Skip back");
  };

  const handleSkipForward = () => {
    // Implementation for skipping forward would require backend support
    console.log("Skip forward");
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <VideoControls
          selectedView={selectedView}
          onViewChange={setSelectedView}
          isPlaying={isPlaying}
          onPlayPause={handlePlayPause}
          onSkipBack={handleSkipBack}
          onSkipForward={handleSkipForward}
        />
        <div className="flex items-center gap-2">
          <span
            className={`h-2 w-2 rounded-full ${
              isConnected ? "bg-green-500" : "bg-red-500"
            }`}
          ></span>
          <span className="text-sm">
            {isConnected ? "Connected" : "Disconnected"}
          </span>
        </div>
      </div>
      <VideoGrid selectedView={selectedView} videos={CAMERA_IDS} />
    </div>
  );
}

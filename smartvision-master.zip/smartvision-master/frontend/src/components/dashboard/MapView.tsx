"use client";

import dynamic from "next/dynamic";
import { Card } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { AssetsSidebar } from "../map/AssetsSidebar";

// Dynamically import the map component with no SSR
const DynamicMap = dynamic(
  () => import("@/components/map/DynamicMap").then((mod) => mod.DynamicMap),
  {
    ssr: false,
    loading: () => (
      <Card className="md:col-span-3 h-[600px] flex items-center justify-center">
        <Skeleton className="w-full h-full rounded-lg" />
      </Card>
    ),
  }
);

export function MapView() {
  return (
    <div className="grid gap-4 md:grid-cols-4">
      <DynamicMap />
      <AssetsSidebar />
    </div>
  );
}

"use client";

import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { TrendingUp } from "lucide-react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  LabelList,
  XAxis,
  Label,
  Pie,
  PieChart,
  LineChart,
  Line,
  YAxis,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import {
  ChartContainer,
  ChartConfig,
  ChartTooltip,
  ChartTooltipContent,
  ChartLegend,
  ChartLegendContent,
} from "../ui/chart";

const data1 = [
  { name: "MAY24", incidents: 13 },
  { name: "JUN24", incidents: 21 },
  { name: "JUL24", incidents: 64 },
  { name: "AUG24", incidents: 40 },
  { name: "SEP24", incidents: 8 },
  { name: "OCT24", incidents: 53 },
  { name: "NOV24", incidents: 36 },
  { name: "DEC24", incidents: 21 },
  { name: "JAN25", incidents: 62 },
  { name: "FEB25", incidents: 43 },
  { name: "MAR25", incidents: 49 },
  { name: "APR25", incidents: 53 },
];

const data2 = [
  { name: "MAY24", incidents: 0 },
  { name: "JUN24", incidents: 0 },
  { name: "JUL24", incidents: 1 },
  { name: "AUG24", incidents: 0 },
  { name: "SEP24", incidents: 0 },
  { name: "OCT24", incidents: 2 },
  { name: "NOV24", incidents: 5 },
  { name: "DEC24", incidents: 7 },
  { name: "JAN25", incidents: 2 },
  { name: "FEB25", incidents: 2 },
  { name: "MAR25", incidents: 1 },
  { name: "APR25", incidents: 0 },
];

const chartData = [
  { browser: "precinct1", visitors: 50, fill: "var(--color-precinct1)" },
  { browser: "precinct4", visitors: 24, fill: "var(--color-precinct4)" },
  { browser: "precinct8", visitors: 10, fill: "var(--color-precinct8)" },
  { browser: "precinct12", visitors: 10, fill: "var(--color-precinct12)" },
  { browser: "precinct11", visitors: 6, fill: "var(--color-precinct11)" },
];

const chartConfig = {
  visitors: {
    label: "Visitors",
  },
  precinct1: {
    label: "Precinct1",
    color: "hsl(var(--chart-1))",
  },
  precinct4: {
    label: "Precinct4",
    color: "hsl(var(--chart-2))",
  },
  precinct8: {
    label: "Precinct8",
    color: "hsl(var(--chart-3))",
  },
  precinct12: {
    label: "Precinct12",
    color: "hsl(var(--chart-4))",
  },
  precinct11: {
    label: "Precinct11",
    color: "hsl(var(--chart-5))",
  },

  incidents: {
    label: "Incidents",
    color: "hsl(var(--chart-1))",
  },
} satisfies ChartConfig;

export function Analytics() {
  return (
    <div className="space-y-4">
      <div className="grid gap-4 md:grid-cols-3">
        <Card className="p-4">
          <h3 className="font-semibold mb-2">
            Total Stray Animals Detection Today
          </h3>
          <div className="flex items-center justify-between">
            <span className="text-3xl font-bold">10</span>
            <Badge variant="secondary">Year-to-date average is 49</Badge>
          </div>
        </Card>

        <Card className="p-4">
          <h3 className="font-semibold mb-2">Total Flood Detection Today</h3>
          <div className="flex items-center justify-between">
            <span className="text-3xl font-bold">0</span>
            <Badge variant="secondary">Year-to-date average is 1</Badge>
          </div>
        </Card>

        <Card className="p-4">
          <h3 className="font-semibold mb-2">Active Security Camera</h3>
          <div className="flex items-center justify-between">
            <span className="text-3xl font-bold">45</span>
            <Badge variant="secondary">5 inactive</Badge>
          </div>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <div className="md:col-span-2">
          <Card className="p-4">
            <h3 className="font-semibold mb-4">Bar Chart - Label</h3>
            <div className="h-[300px]">
              <ChartContainer config={chartConfig} className="h-full w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart accessibilityLayer data={data1} margin={{ top: 0 }}>
                    <CartesianGrid vertical={false} />
                    <XAxis
                      dataKey="name"
                      tickLine={false}
                      tickMargin={10}
                      axisLine={false}
                    />
                    <ChartTooltip
                      cursor={false}
                      content={<ChartTooltipContent hideLabel />}
                    />
                    <Bar
                      dataKey="incidents"
                      fill="var(--color-incidents)"
                      radius={8}
                    >
                      <LabelList
                        position="top"
                        offset={12}
                        className="fill-foreground"
                        fontSize={12}
                      />
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </ChartContainer>
            </div>
          </Card>
        </div>

        <div>
          <Card className="flex flex-col w-full">
            <CardHeader className="items-center pb-0">
              <CardTitle>Pie Chart - Legend</CardTitle>
              <CardDescription>January - June 2024</CardDescription>
            </CardHeader>
            <CardContent className="p-6 flex-1 pb-0">
              <ChartContainer
                config={chartConfig}
                className="mx-auto aspect-square max-h-[300px]"
              >
                <PieChart>
                  <Pie data={chartData} dataKey="visitors" />
                  <ChartLegend
                    content={<ChartLegendContent nameKey="browser" />}
                    className="-translate-y-2 flex-wrap gap-2 [&>*]:basis-1/4 [&>*]:justify-center"
                  />
                </PieChart>
              </ChartContainer>
            </CardContent>
          </Card>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card className="md:col-span-2 p-4">
          <h3 className="font-semibold mb-4">
            Flood Detection Frequency (Monthly)
          </h3>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={data2}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis
                  dataKey="name"
                  tickLine={false}
                  tickMargin={10}
                  axisLine={true}
                  fontSize={12}
                />
                <YAxis />
                <Tooltip />
                <Line
                  type="monotone"
                  dataKey="incidents"
                  stroke="hsl(var(--primary))"
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card className="flex flex-col">
          <CardHeader className="items-center pb-0">
            <CardTitle>Pie Chart - Donut with Text</CardTitle>
            <CardDescription>January - June 2024</CardDescription>
          </CardHeader>
          <CardContent className="flex-1 pb-0">
            <ChartContainer
              config={chartConfig}
              className="mx-auto aspect-square max-h-[250px]"
            >
              <PieChart>
                <ChartTooltip content={<ChartTooltipContent hideLabel />} />
                <Pie
                  data={chartData}
                  dataKey="visitors"
                  label
                  nameKey="browser"
                />
              </PieChart>
            </ChartContainer>
          </CardContent>
          <CardFooter className="flex-col gap-2 text-sm">
            <div className="flex items-center gap-2 font-medium leading-none">
              Trending up by 5.2% this month <TrendingUp className="h-4 w-4" />
            </div>
            <div className="leading-none text-muted-foreground">
              Showing total visitors for the last 6 months
            </div>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}

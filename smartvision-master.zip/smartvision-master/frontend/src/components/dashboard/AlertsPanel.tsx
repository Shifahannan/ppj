"use client";

import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import {
  Bell,
  AlertTriangle,
  Shield,
  Mail,
  MessageSquare,
  Cat,
  Droplets,
} from "lucide-react";
import {
  AlertData,
  AlertsResponse,
  ActiveAlertsProps,
} from "@/types/detection";
import socketClient from "@/lib/websocket";
import { useToast } from "@/hooks/use-toast";
import api from "@/lib/api";

export function AlertsPanel({ limit = 5 }: ActiveAlertsProps) {
  const [alerts, setAlerts] = useState<AlertData[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isConnected, setIsConnected] = useState(false);
  const [notificationSettings, setNotificationSettings] = useState({
    inApp: true,
    email: false,
    sms: false,
    criticalOnly: false,
  });
  const { toast } = useToast();

  useEffect(() => {
    // Load initial alerts
    const loadAlerts = async () => {
      try {
        setIsLoading(true);
        const response: AlertsResponse = await api.getAlerts(1, limit);
        setAlerts(response.alerts);
      } catch (error) {
        console.error("Failed to load alerts:", error);
        toast({
          title: "Error loading alerts",
          description: "Could not retrieve alert data from the server",
          variant: "destructive",
        });
      } finally {
        setIsLoading(false);
      }
    };

    loadAlerts();

    // Set up WebSocket connection and handlers
    socketClient.setEventHandlers({
      onConnect: () => {
        setIsConnected(true);
        toast({
          title: "Connected to alert system",
          description: "You will receive real-time alerts",
        });
      },
      onDisconnect: () => {
        setIsConnected(false);
        toast({
          title: "Disconnected from alert system",
          description: "Real-time alerts are currently unavailable",
          variant: "destructive",
        });
      },
      onNewAlert: (newAlert: AlertData) => {
        // Add the new alert to the top of the list
        setAlerts((prevAlerts) => {
          // Limit to the specified number of alerts in the panel
          const updatedAlerts = [newAlert, ...prevAlerts.slice(0, limit - 1)];
          return updatedAlerts;
        });

        // Show notification if enabled
        if (notificationSettings.inApp) {
          // Skip if criticalOnly is enabled and this is not a high confidence alert
          if (notificationSettings.criticalOnly && newAlert.confidence < 0.75) {
            return;
          }

          toast({
            title: `New ${newAlert.alert_type} alert`,
            description: newAlert.details,
            variant: newAlert.confidence > 0.75 ? "destructive" : "default",
          });
        }
      },
      onError: (error) => {
        console.error("WebSocket error:", error);
        toast({
          title: "Connection error",
          description: "Failed to connect to the alert system",
          variant: "destructive",
        });
      },
    });

    // Connect to WebSocket
    socketClient.connect();

    // Cleanup on unmount
    return () => {
      socketClient.disconnect();
    };
  }, [
    toast,
    notificationSettings.inApp,
    notificationSettings.criticalOnly,
    limit,
  ]);

  // Toggle notification settings
  const toggleSetting = (setting: keyof typeof notificationSettings) => {
    setNotificationSettings((prev) => ({
      ...prev,
      [setting]: !prev[setting],
    }));
  };

  // Get appropriate icon based on alert type
  const getAlertIcon = (type: string) => {
    switch (type) {
      case "animal":
        return <Cat className="h-5 w-5 text-amber-500 flex-shrink-0" />;
      case "flood":
        return <Droplets className="h-5 w-5 text-blue-500 flex-shrink-0" />;
      default:
        return (
          <AlertTriangle className="h-5 w-5 text-yellow-500 flex-shrink-0" />
        );
    }
  };

  // Get appropriate badge style based on confidence
  const getBadgeVariant = (confidence: number) => {
    if (confidence > 0.8) return "destructive";
    if (confidence > 0.6) return "default";
    return "secondary";
  };

  // Format the timestamp to a relative time (e.g., "2 mins ago")
  const getRelativeTime = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.round(diffMs / 60000);

    if (diffMins < 1) return "Just now";
    if (diffMins < 60) return `${diffMins} mins ago`;

    const diffHours = Math.floor(diffMins / 60);
    if (diffHours < 24) return `${diffHours} hours ago`;

    return date.toLocaleDateString();
  };

  return (
    <div className="grid gap-4 md:grid-cols-2">
      <Card className="p-4">
        <div className="flex justify-between items-center mb-4">
          <h3 className="font-semibold">Active Alerts</h3>
          <Badge variant={isConnected ? "outline" : "secondary"}>
            {isConnected ? "Live" : "Offline"}
          </Badge>
        </div>
        <div className="space-y-4">
          {isLoading ? (
            <div className="py-8 text-center text-muted-foreground">
              Loading alerts...
            </div>
          ) : alerts.length === 0 ? (
            <div className="py-8 text-center text-muted-foreground">
              No active alerts
            </div>
          ) : (
            alerts.map((alert) => (
              <div
                key={alert.id}
                className="flex items-start space-x-3 p-3 bg-secondary rounded-lg"
              >
                {getAlertIcon(alert.alert_type)}
                <div className="flex-1">
                  <div className="flex justify-between items-start">
                    <h4 className="font-medium">
                      {alert.alert_type === "animal"
                        ? "Stray Animal Detected"
                        : "Potential Flooding"}
                    </h4>
                    <Badge variant={getBadgeVariant(alert.confidence)}>
                      {alert.confidence > 0.8
                        ? "Critical"
                        : alert.confidence > 0.6
                        ? "Warning"
                        : "Info"}
                    </Badge>
                  </div>
                  <p className="text-sm text-muted-foreground mt-1">
                    {alert.details}
                  </p>
                  {alert.image && (
                    <div className="mt-2 rounded-md overflow-hidden">
                      <img
                        src={`data:image/jpeg;base64,${alert.image}`}
                        alt={`Alert ${alert.id} image`}
                        className="w-full h-auto max-h-32 object-cover"
                      />
                    </div>
                  )}
                  <p className="text-xs text-muted-foreground mt-2">
                    {getRelativeTime(alert.timestamp)}
                  </p>
                </div>
              </div>
            ))
          )}
        </div>
      </Card>

      <Card className="p-4">
        <h3 className="font-semibold mb-4">Notification Settings</h3>
        <div className="space-y-4">
          {[
            {
              icon: Bell,
              label: "In-App Notifications",
              enabled: notificationSettings.inApp,
              setting: "inApp" as const,
            },
            {
              icon: Mail,
              label: "Email Alerts",
              enabled: notificationSettings.email,
              setting: "email" as const,
            },
            {
              icon: MessageSquare,
              label: "SMS Alerts",
              enabled: notificationSettings.sms,
              setting: "sms" as const,
            },
            {
              icon: Shield,
              label: "Critical Alerts Only",
              enabled: notificationSettings.criticalOnly,
              setting: "criticalOnly" as const,
            },
          ].map((setting, i) => (
            <div key={i} className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <setting.icon className="h-5 w-5" />
                <span>{setting.label}</span>
              </div>
              <Switch
                checked={setting.enabled}
                onCheckedChange={() => toggleSetting(setting.setting)}
              />
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

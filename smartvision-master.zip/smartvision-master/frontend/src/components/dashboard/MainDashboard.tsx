"use client";

import { CompactMap } from "@/components/dashboard/widgets/CompactMap";
import { CompactVideoFeeds } from "@/components/dashboard/widgets/CompactVideoFeeds";
import { ActiveAlerts } from "@/components/dashboard/widgets/ActiveAlerts";
import { MetricsOverview } from "@/components/dashboard/widgets/MetricsOverview";

export function MainDashboard() {
  return (
    <div className="space-y-4">
      <MetricsOverview />

      <div className="grid gap-4 lg:grid-cols-2">
        <div className="space-y-4">
          <CompactVideoFeeds />
          <CompactMap />
        </div>

        <div className="space-y-4">
          <ActiveAlerts limit={2} />
        </div>
      </div>
    </div>
  );
}

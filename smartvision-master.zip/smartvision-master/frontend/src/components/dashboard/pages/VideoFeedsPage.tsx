"use client";

import { VideoFeeds } from "@/components/dashboard/VideoFeeds";

export function VideoFeedsPage() {
  return <VideoFeeds />;
}

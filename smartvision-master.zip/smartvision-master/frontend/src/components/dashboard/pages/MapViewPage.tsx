"use client";

import { MapView } from "@/components/dashboard/MapView";

export function MapViewPage() {
  return <MapView key="map-view" />;
}

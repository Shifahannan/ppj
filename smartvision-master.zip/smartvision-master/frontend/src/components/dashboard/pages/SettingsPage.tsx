"use client";

import { Card } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Bell, Mail, MessageSquare, Shield } from "lucide-react";

export function SettingsPage() {
  return (
    <div className="space-y-4 max-w-2xl mx-auto">
      <h2 className="text-2xl font-bold mb-6">Settings</h2>

      <Card className="p-4">
        <h3 className="font-semibold mb-4">Notification Preferences</h3>
        <div className="space-y-4">
          {[
            { icon: Bell, label: "In-App Notifications", enabled: true },
            { icon: Mail, label: "Email Alerts", enabled: true },
            { icon: MessageSquare, label: "SMS Alerts", enabled: false },
            { icon: Shield, label: "Critical Alerts Only", enabled: false },
          ].map((setting, i) => (
            <div key={i} className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <setting.icon className="h-5 w-5" />
                <span>{setting.label}</span>
              </div>
              <Switch checked={setting.enabled} />
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

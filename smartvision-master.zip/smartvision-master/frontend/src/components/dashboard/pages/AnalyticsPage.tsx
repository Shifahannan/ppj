"use client";

import { Analytics } from "@/components/dashboard/Analytics";

export function AnalyticsPage() {
  return <Analytics />;
}

"use client";

import { Card } from "@/components/ui/card";

export function AIInsights() {
  return (
    <Card className="p-4">
      <h3 className="font-semibold mb-4">AI Insights</h3>
      <div className="space-y-3">
        <div className="p-3 bg-secondary rounded-lg">
          <p className="text-sm">
            Unusual activity detected in Zone C between 02:00-03:00
          </p>
        </div>
        <div className="p-3 bg-secondary rounded-lg">
          <p className="text-sm">
            Pattern: Increased motion detection during shift changes
          </p>
        </div>
      </div>
    </Card>
  );
}

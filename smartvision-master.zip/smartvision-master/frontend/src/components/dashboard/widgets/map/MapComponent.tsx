"use client";

//import { useEffect } from "react";
import { MapContainer, TileLayer } from "react-leaflet";
import { MapLayers } from "./MapLayers";
import { useMapIcons } from "@/hooks/useMapIcons";
import "leaflet/dist/leaflet.css";
import { MAP_CONFIG } from "@/lib/constants/map-config";

export default function MapComponent() {
  useMapIcons();

  return (
    <div
      className="aspect-video relative rounded-lg overflow-hidden"
      suppressHydrationWarning
    >
      <MapContainer
        key="map-container"
        center={MAP_CONFIG.center as [number, number]}
        zoom={MAP_CONFIG.zoom}
        className="h-full w-full"
        zoomControl={false}
        dragging={false}
        scrollWheelZoom={false}
      >
        <TileLayer
          url={MAP_CONFIG.tileLayer.url}
          attribution={MAP_CONFIG.tileLayer.attribution}
        />
        <MapLayers />
      </MapContainer>
    </div>
  );
}

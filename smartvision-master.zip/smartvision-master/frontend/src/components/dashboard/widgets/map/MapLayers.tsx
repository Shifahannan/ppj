"use client";

import { PlantationBoundary } from "./layers/PlantationBoundary";
import { AssetMarkers } from "./layers/AssetMarkers";

export function MapLayers() {
  return (
    <>
      <PlantationBoundary />
      <AssetMarkers />
    </>
  );
}

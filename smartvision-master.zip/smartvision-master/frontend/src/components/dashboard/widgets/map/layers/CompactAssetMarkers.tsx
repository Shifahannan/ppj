"use client";

import { Marker, Popup } from "react-leaflet";
import { MAP_CONFIG, Asset } from "@/lib/constants/map-config";
import { getCompactAssetIcon } from "@/lib/utils/map-utils";

export function CompactAssetMarkers() {
  return (
    <>
      {MAP_CONFIG.assets.map((asset: Asset) => (
        <Marker
          key={asset.id}
          position={asset.position as [number, number]}
          icon={getCompactAssetIcon(asset.type)}
        >
          <Popup>
            <div className="p-1">
              <p className="text-xs font-medium">{asset.label}</p>
            </div>
          </Popup>
        </Marker>
      ))}
    </>
  );
}

"use client";

import { Marker, Popup } from "react-leaflet";
import { MAP_CONFIG } from "@/lib/constants/map-config";
import { getCompactAssetIcon } from "@/lib/utils/map-utils";

interface LocalAsset {
  id: string;
  label: string;
  type: string;
  position: [number, number];
}

export function CompactAssetMarkers() {
  return (
    <>
      {MAP_CONFIG.assets.map((asset: LocalAsset) => (
        <Marker
          key={asset.id}
          position={asset.position}
          icon={getCompactAssetIcon(asset.type)}
        >
          <Popup>
            <div className="p-1">
              <p className="text-xs font-medium">{asset.label}</p>
            </div>
          </Popup>
        </Marker>
      ))}
    </>
  );
}

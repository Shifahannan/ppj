"use client";

import { useEffect, useState } from "react";
import { MapContainer, TileLayer } from "react-leaflet";
import { MAP_CONFIG } from "@/lib/constants/map-config";
import { CompactAssetMarkers } from "./layers/CompactAssetMarkers";
import { CompactPlantationBoundary } from "./layers/CompactPlantationBoundary";
import "leaflet/dist/leaflet.css";

export function CompactMapView() {
  const [isMounted, setIsMounted] = useState(false);

  useEffect(() => {
    setIsMounted(true);
  }, []);

  if (!isMounted) {
    return null;
  }

  return (
    <div className="aspect-video relative rounded-lg overflow-hidden">
      <MapContainer
        key="compact-map"
        center={MAP_CONFIG.center as [number, number]}
        zoom={MAP_CONFIG.zoom}
        className="h-full w-full"
        zoomControl={false}
        dragging={false}
        scrollWheelZoom={false}
        attributionControl={false}
      >
        <TileLayer
          url={MAP_CONFIG.tileLayer.url}
          attribution={MAP_CONFIG.tileLayer.attribution}
        />
        <CompactPlantationBoundary />
        <CompactAssetMarkers />
      </MapContainer>
    </div>
  );
}

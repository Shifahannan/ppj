// components/CompactVideoFeeds.tsx
"use client";

import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Maximize2 } from "lucide-react";
import { VideoPlayer } from "@/components/video/VideoPlayer";
import { useEffect, useState } from "react";
import socketClient from "@/lib/websocket";
import SocketDebug from "@/components/debug/SocketDebug";

// Define camera IDs - these should match what your backend sends
const CAMERA_IDS = ["cam1", "cam2", "cam3", "cam4"];

export function CompactVideoFeeds() {
  const [isConnected, setIsConnected] = useState(false);

  useEffect(() => {
    // Set up the global socket connection and status
    const handleConnect = () => {
      console.log("Socket connected in CompactVideoFeeds");
      setIsConnected(true);
    };

    const handleDisconnect = () => {
      console.log("Socket disconnected in CompactVideoFeeds");
      setIsConnected(false);
    };

    socketClient.setEventHandlers({
      onConnect: handleConnect,
      onDisconnect: handleDisconnect,
    });

    // Connect to the socket server if not already connected
    if (!socketClient.isConnected()) {
      console.log("Connecting socket from CompactVideoFeeds");
      socketClient.connect();
    } else {
      console.log("Socket already connected in CompactVideoFeeds");
      setIsConnected(true);
    }

    // Clean up on unmount - just remove our specific handlers
    return () => {
      socketClient.setEventHandlers({});
    };
  }, []);

  return (
    <>
      <Card className="p-4">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold">Live Feeds</h3>
          <div className="flex items-center gap-2">
            <span
              className={`h-2 w-2 rounded-full ${
                isConnected ? "bg-green-500" : "bg-red-500"
              }`}
            ></span>
            <span className="text-xs text-muted-foreground">
              {isConnected ? "Connected" : "Disconnected"}
            </span>
            <Button variant="ghost" size="sm">
              <Maximize2 className="h-4 w-4" />
            </Button>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-4">
          {CAMERA_IDS.map((cameraId, index) => (
            <VideoPlayer key={cameraId} cameraId={cameraId} />
          ))}
        </div>
      </Card>

      {/* Add the socket debugger component */}
      <SocketDebug />
    </>
  );
}

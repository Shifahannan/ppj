"use client";

import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { TrendingUp, Clock, Video, Map } from "lucide-react";
import { useEffect, useState } from "react";
import { StatsData } from "@/types/detection";

export function MetricsOverview() {
  const [stats, setStats] = useState<StatsData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const response = await fetch("http://localhost:5000/api/stats");
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        setStats(data);
      } catch (err) {
        setError(err instanceof Error ? err.message : "Failed to fetch stats");
      } finally {
        setLoading(false);
      }
    };

    fetchStats();
  }, []);

  if (loading) {
    return (
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {[...Array(4)].map((_, i) => (
          <Card key={i} className="p-4">
            <Skeleton className="h-6 w-32 mb-2" />
            <Skeleton className="h-8 w-16 mt-2" />
            <Skeleton className="h-4 w-48 mt-2" />
          </Card>
        ))}
      </div>
    );
  }

  if (error) {
    return (
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Card className="p-4 text-destructive bg-destructive/10">
          Error: {error}
        </Card>
      </div>
    );
  }

  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
      <Card className="p-4">
        <div className="flex items-start justify-between">
          <div>
            <p className="text-sm font-medium">Total Stray Animals Today</p>
            <h3 className="text-2xl font-bold mt-2">
              {stats?.by_type?.animal || 0}
            </h3>
          </div>
          <TrendingUp className="h-5 w-5" />
        </div>
        <Badge variant="secondary" className="mt-2">
          Real-time detection system
        </Badge>
      </Card>

      <Card className="p-4">
        <div className="flex items-start justify-between">
          <div>
            <p className="text-sm font-medium">Total Flood Detection Today</p>
            <h3 className="text-2xl font-bold mt-2">
              {stats?.by_type?.flood || 0}
            </h3>
          </div>
          <Clock className="h-5 w-5" />
        </div>
        <Badge variant="secondary" className="mt-2">
          Last 24h monitoring
        </Badge>
      </Card>

      <Card className="p-4">
        <div className="flex items-start justify-between">
          <div>
            <p className="text-sm font-medium">Active Cameras</p>
            <h3 className="text-2xl font-bold mt-2">1</h3>
          </div>
          <Video className="h-5 w-5" />
        </div>
        <Badge variant="secondary" className="mt-2">
          Live streaming enabled
        </Badge>
      </Card>

      <Card className="p-4">
        <div className="flex items-start justify-between">
          <div>
            <p className="text-sm font-medium">Monitoring Zones</p>
            <h3 className="text-2xl font-bold mt-2">3</h3>
          </div>
          <Map className="h-5 w-5" />
        </div>
        <Badge variant="secondary" className="mt-2">
          Heatmap coverage
        </Badge>
      </Card>
    </div>
  );
}

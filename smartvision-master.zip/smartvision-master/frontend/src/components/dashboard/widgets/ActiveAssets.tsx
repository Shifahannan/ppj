"use client";

import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export function ActiveAssets() {
  return (
    <Card className="p-4">
      <h3 className="font-semibold mb-2">Active Assets</h3>
      <div className="space-y-2">
        <div className="flex justify-between items-center">
          <span>Vehicles</span>
          <Badge>12/15</Badge>
        </div>
        <div className="flex justify-between items-center">
          <span>Personnel</span>
          <Badge>45/50</Badge>
        </div>
        {/* <div className="flex justify-between items-center">
          <span>Drones</span>
          <Badge>3/4</Badge>
        </div> */}
      </div>
    </Card>
  );
}

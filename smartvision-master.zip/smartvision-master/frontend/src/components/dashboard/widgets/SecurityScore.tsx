"use client";

import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export function SecurityScore() {
  return (
    <Card className="p-4">
      <h3 className="font-semibold mb-4">Security Score</h3>
      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <span>Overall Rating</span>
          <Badge variant="secondary">92/100</Badge>
        </div>
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span>Camera Coverage</span>
            <span>95%</span>
          </div>
          <div className="flex justify-between text-sm">
            <span>Response Time</span>
            <span>98%</span>
          </div>
        </div>
      </div>
    </Card>
  );
}

"use client";

import { Card } from "@/components/ui/card";

export function RecentActivity() {
  return (
    <Card className="p-4">
      <h3 className="font-semibold mb-2">Recent Activity</h3>
      <div className="space-y-2 text-sm">
        <p suppressHydrationWarning>Vehicle #23 entered Zone A</p>

        <p suppressHydrationWarning>New personnel badge scan</p>
      </div>
    </Card>
  );
}

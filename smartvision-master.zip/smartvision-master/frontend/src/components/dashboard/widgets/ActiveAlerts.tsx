"use client";

import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { AlertTriangle } from "lucide-react";
import { AlertData, ActiveAlertsProps } from "@/types/detection";
import { useEffect, useState } from "react";

export function ActiveAlerts({ limit = 10 }: ActiveAlertsProps) {
  const [alerts, setAlerts] = useState<AlertData[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchAlerts = async () => {
      try {
        const response = await fetch(
          "http://localhost:5000/api/alerts?per_page=10"
        );
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        setAlerts(data.alerts.slice(0, limit));
      } catch (err) {
        setError(err instanceof Error ? err.message : "Failed to fetch alerts");
      } finally {
        setLoading(false);
      }
    };

    fetchAlerts();
  }, [limit]);

  const formatDate = (isoString: string) => {
    const date = new Date(isoString);
    return new Intl.DateTimeFormat("en-US", {
      weekday: "long",
      day: "numeric",
      month: "long",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    }).format(date);
  };

  if (loading) {
    return (
      <Card className="p-4">
        <h3 className="font-semibold mb-4">Active Alerts</h3>
        <div className="space-y-3">
          {[...Array(3)].map((_, i) => (
            <Skeleton key={i} className="h-[72px] w-full rounded-lg" />
          ))}
        </div>
      </Card>
    );
  }

  if (error) {
    return (
      <Card className="p-4">
        <h3 className="font-semibold mb-4">Active Alerts</h3>
        <div className="text-destructive p-3 rounded-lg bg-destructive/10">
          Error: {error}
        </div>
      </Card>
    );
  }

  return (
    <Card className="p-4">
      <h3 className="font-semibold mb-4">Active Alerts</h3>
      <div className="space-y-3">
        {alerts.length === 0 ? (
          <div className="p-3 text-muted-foreground text-center">
            No active alerts
          </div>
        ) : (
          alerts.map((alert) => (
            <div
              key={alert.id}
              className="flex items-start space-x-3 p-3 bg-secondary rounded-lg"
            >
              <AlertTriangle className="h-5 w-5 text-yellow-500 flex-shrink-0" />
              <div className="flex-1">
                <div className="flex justify-between items-start">
                  <h4 className="font-medium">{alert.details}</h4>
                  <Badge
                    variant={
                      alert.alert_type === "flood" ? "destructive" : "secondary"
                    }
                  >
                    {alert.alert_type}
                  </Badge>
                </div>
                <p className="text-sm text-muted-foreground">
                  {formatDate(alert.timestamp)}
                </p>
                <p className="text-xs mt-1 text-muted-foreground">
                  Confidence: {(alert.confidence * 100).toFixed(1)}%
                </p>
              </div>
            </div>
          ))
        )}
      </div>
    </Card>
  );
}

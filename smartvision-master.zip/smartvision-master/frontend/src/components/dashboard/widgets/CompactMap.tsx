"use client";

import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Truck, User, Move } from "lucide-react";
import dynamic from "next/dynamic";
import { Skeleton } from "@/components/ui/skeleton";
import { useEffect, useRef, useState } from "react";
import io from "socket.io-client";
import Heatmap from "heatmap.js";

// Dynamically import MapView with no SSR
const MapView = dynamic(
  () => import("./map/CompactMapView").then((mod) => mod.CompactMapView),
  {
    ssr: false,
    loading: () => (
      <div className="aspect-video bg-secondary rounded-lg">
        <Skeleton className="w-full h-full" />
      </div>
    ),
  }
);

export function CompactMap() {
  const heatmapContainerRef = useRef<HTMLDivElement>(null);
  const [heatmapInstance, setHeatmapInstance] = useState<any>(null);
  const [points, setPoints] = useState<
    Array<{ x: number; y: number; value: number }>
  >([]);

  useEffect(() => {
    // Initialize heatmap
    if (heatmapContainerRef.current && !heatmapInstance) {
      const config = {
        container: heatmapContainerRef.current,
        radius: 30,
        maxOpacity: 0.5,
        minOpacity: 0,
        blur: 0.75,
      };
      setHeatmapInstance(Heatmap.create(config));
    }
  }, []);

  useEffect(() => {
    const socket = io("http://localhost:5000");

    // Listen for heatmap updates
    socket.on(
      "heatmap_update",
      (data: { x: number; y: number; intensity: number }) => {
        setPoints((prev) => [
          ...prev,
          { x: data.x, y: data.y, value: data.intensity * 100 },
        ]);
      }
    );

    return () => {
      socket.disconnect();
    };
  }, []);

  // Update heatmap data when points change
  useEffect(() => {
    if (heatmapInstance) {
      heatmapInstance.setData({
        max: 100,
        min: 0,
        data: points,
      });
    }
  }, [points, heatmapInstance]);

  return (
    <Card className="p-4">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-semibold">Live Map</h3>
        <div className="flex gap-2">
          <Badge variant="secondary" className="flex items-center gap-1">
            <Truck className="h-3 w-3" /> 12
          </Badge>
          <Badge variant="secondary" className="flex items-center gap-1">
            <User className="h-3 w-3" /> 45
          </Badge>
          <Badge variant="secondary" className="flex items-center gap-1">
            <Move className="h-3 w-3" /> 3
          </Badge>
        </div>
      </div>

      <div className="relative aspect-video rounded-lg overflow-hidden">
        {/* Heatmap container */}
        <div
          ref={heatmapContainerRef}
          className="absolute inset-0 w-full h-full"
        />

        {/* Map component */}
        <div className="absolute inset-0 w-full h-full">
          <MapView />
        </div>
      </div>
    </Card>
  );
}

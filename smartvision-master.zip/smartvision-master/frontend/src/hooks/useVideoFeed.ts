// hooks/useVideoFeed.ts
import { useEffect, useState, useCallback, useRef } from 'react';
import socketClient, { FrameUpdate } from '@/lib/websocket';

export interface VideoFrame {
  image: string;
  timestamp: string;
  camera_id?: string;
}

interface UseVideoFeedOptions {
  cameraId?: string;
  autoConnect?: boolean;
}

export function useVideoFeed({ cameraId = 'cam1', autoConnect = true }: UseVideoFeedOptions = {}) {
  const [frame, setFrame] = useState<VideoFrame | null>(null);
  const [isConnected, setIsConnected] = useState<boolean>(socketClient.isConnected());
  const [error, setError] = useState<Error | null>(null);
  const [hasSubscribed, setHasSubscribed] = useState(false);
  
  // Keep a ref to the frame to avoid stale closures in event handlers
  const frameRef = useRef<VideoFrame | null>(null);
  
  // Store the last connection time to avoid multiple rapid subscribe attempts
  const lastSubscribeTime = useRef(0);
  
  // Keep track of the camera ID
  const cameraIdRef = useRef(cameraId);
  useEffect(() => {
    cameraIdRef.current = cameraId;
  }, [cameraId]);
  
  // Create stable function references with useCallback
  const connect = useCallback(() => {
    console.log("Attempting to connect to socket server...");
    socketClient.connect();
  }, []);
  
  const disconnect = useCallback(() => {
    console.log("Disconnecting from socket server...");
    socketClient.disconnect();
  }, []);
  
  const reconnect = useCallback(() => {
    console.log("Reconnecting to socket server...");
    setHasSubscribed(false);
    socketClient.reconnect();
  }, []);
  
  // Subscribe to video feed
  const subscribeToVideo = useCallback(() => {
    const now = Date.now();
    if (now - lastSubscribeTime.current < 2000) {
      console.log("Skipping subscription, too soon after last attempt");
      return;
    }
    
    console.log(`Subscribing to video feed for camera: ${cameraIdRef.current}`);
    socketClient.emit('subscribe_video', { camera_id: cameraIdRef.current });
    lastSubscribeTime.current = now;
    setHasSubscribed(true);
  }, []);
  
  useEffect(() => {
    console.log(`Setting up video feed hook for camera: ${cameraId}`);
    console.log(`Initial socket connection state: ${socketClient.isConnected()}`);
    
    // Define event handlers
    const onConnect = () => {
      console.log("Socket connected successfully");
      setIsConnected(true);
      setError(null);
      
      // Subscribe to video feed when connected
      if (!hasSubscribed) {
        subscribeToVideo();
      }
    };
    
    const onDisconnect = () => {
      console.log("Socket disconnected");
      setIsConnected(false);
      setHasSubscribed(false);
    };
    
    const onError = (err: Error) => {
      console.error("Socket error:", err);
      setError(err);
      setIsConnected(false);
    };
    
    const onFrameUpdate = (frameData: FrameUpdate) => {
      // Only process frames for this camera if a cameraId is specified
      if (!cameraId || frameData.camera_id === cameraId) {
        // Log frame receipt (but not too often to avoid console spam)
        if (Math.random() < 0.1) { // Log roughly 10% of frames
          console.log(`Frame received from camera: ${frameData.camera_id}, timestamp: ${frameData.timestamp}`);
          console.log(`Frame image length: ${frameData.image.length} characters`);
        }
        
        // Update frame state
        const newFrame = {
          image: frameData.image,
          timestamp: frameData.timestamp,
          camera_id: frameData.camera_id
        };
        
        setFrame(newFrame);
        frameRef.current = newFrame;
      }
    };
    
    // Configure event handlers
    socketClient.setEventHandlers({
      onConnect,
      onDisconnect,
      onError,
      onFrameUpdate
    });
    
    // Connect to WebSocket if autoConnect is true and not already connected
    if (autoConnect && !socketClient.isConnected()) {
      connect();
    } else if (socketClient.isConnected()) {
      // If already connected, subscribe to video feed
      setIsConnected(true);
      if (!hasSubscribed) {
        subscribeToVideo();
      }
    }
    
    // Cleanup on unmount
    return () => {
      if (socketClient.isConnected() && hasSubscribed) {
        console.log(`Unsubscribing from video feed for camera: ${cameraIdRef.current}`);
        socketClient.emit('unsubscribe_video');
      }
      
      // Remove our specific handlers
      socketClient.setEventHandlers({});
    };
  }, [cameraId, autoConnect, connect, hasSubscribed, subscribeToVideo]);

  return {
    frame,
    isConnected,
    error,
    connect,
    disconnect,
    reconnect
  };
}
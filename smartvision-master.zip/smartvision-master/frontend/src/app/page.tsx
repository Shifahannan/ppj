import SecurityDashboard from "@/components/SecurityDashboard";

export default function Home() {
  return <SecurityDashboard />;
}

/**
 * Alert data interface
 */
export interface AlertData {
    id: number;
    timestamp: string;
    alert_type: string; // 'animal' | 'flood';
    details: string;
    confidence: number;
    image?: string; // Base64 encoded image
  }

export interface ActiveAlertsProps {
  limit?: number;
}
  
  /**
   * Pagination information
   */
  export interface Pagination {
    page: number;
    per_page: number;
    total: number;
    pages: number;
  }
  
  /**
   * Alert response from API
   */
  export interface AlertsResponse {
    alerts: AlertData[];
    pagination: Pagination;
  }
  
  /**
   * Heatmap data point
   */
  export interface HeatmapPoint {
    x: number;
    y: number;
    intensity: number;
  }
  
  /**
   * Statistics interfaces
   */
  export interface TypeCounts {
    [key: string]: number;
  }
  
  export interface HourlyCounts {
    [hour: string]: number;
  }
  
  export interface ConfidenceAvg {
    [key: string]: number;
  }
  
  export interface StatsData {
    by_type: TypeCounts;
    by_hour: HourlyCounts;
    avg_confidence: ConfidenceAvg;
  }
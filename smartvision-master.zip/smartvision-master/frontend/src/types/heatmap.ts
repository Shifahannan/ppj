declare module "heatmap.js" {
    interface HeatmapConfiguration {
      container: HTMLElement;
      radius?: number;
      maxOpacity?: number;
      minOpacity?: number;
      blur?: number;
    }
  
    interface HeatmapDataPoint {
      x: number;
      y: number;
      value: number;
    }
  
    interface HeatmapData {
      max: number;
      min?: number;
      data: HeatmapDataPoint[];
    }
  
    interface HeatmapInstance {
      setData(data: HeatmapData): void;
      addData(data: HeatmapDataPoint | HeatmapDataPoint[]): void;
      repaint(): void;
    }
  
    export function create(config: HeatmapConfiguration): HeatmapInstance;
  }
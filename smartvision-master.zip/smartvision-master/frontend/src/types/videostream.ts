export interface VideoFrame {
    image: string;
    timestamp: string;
    camera_id: string;
  }
  
  export interface VideoAlert {
    id: number;
    timestamp: string;
    type: 'animal' | 'flood';
    details: string;
    confidence: number;
    image: string;
  }
  
  export interface VideoStats {
    by_type: Record<string, number>;
    by_hour: Record<string, number>;
    avg_confidence: Record<string, number>;
  }
  
  export interface CameraConfig {
    id: string;
    name: string;
    url: string;
    location: string;
  }